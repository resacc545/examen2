package com.example.syscaso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
