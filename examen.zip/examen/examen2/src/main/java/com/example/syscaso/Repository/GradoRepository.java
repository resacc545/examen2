package com.example.syscaso.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.syscaso.entity.Grado;



@Repository
public interface GradoRepository extends JpaRepository<Grado, Long> {

}
