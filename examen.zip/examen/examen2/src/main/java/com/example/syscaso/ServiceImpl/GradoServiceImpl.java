package com.example.syscaso.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.syscaso.Repository.GradoRepository;
import com.example.syscaso.Service.GradoService;
import com.example.syscaso.entity.Grado;


@Service
public class GradoServiceImpl implements GradoService{
	
	
	@Autowired
	private GradoRepository gradoRepository;
	@Override
	public Grado create(Grado g) {
		// TODO Auto-generated method stub
		return gradoRepository.save(g);
	}

	@Override
	public Grado update(Grado g) {
		// TODO Auto-generated method stub
		return gradoRepository.save(g);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		gradoRepository.deleteById(id);
	}

	@Override
	public Optional<Grado> read(Long id) {
		// TODO Auto-generated method stub
		return gradoRepository.findById(id);
	}

	@Override
	public List<Grado> readAll() {
		// TODO Auto-generated method stub
		return gradoRepository.findAll();
	}

}
